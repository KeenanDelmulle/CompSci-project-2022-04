/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

public class Enemies {

    // private final int rblocks, rhealth, rspeed;
    int rhealth;
    double rspeed;
    double rx;
    double ry;
    boolean ractive;

    public Enemies(int health, double speed, double x, double y, boolean active) {
        rhealth = health;
        rspeed = speed;
        rx = x;
        ry = y;
        ractive = active;
    }

    public void generateAliens() {
       /* for (int i = 0; i < (rblocks - 1); i++) {
            for (int x = 8; x < 100; x += 12) {
                StdDraw.square(x, (i * 12) + 70, 4);  //each level make another layer
            }
        */
        StdDraw.square(rx, ry, 4);

           /* for (int y = 70; y < 100; y += 12) {
                for (int i = 8; i < 100; i += 12) {
                    StdDraw.square(i, y, 4);
                } */
    }

    public double getRx() {
        return rx;
    }

    public double getRy() {
        return ry;
    }

    public void changeState(boolean value) {
        ractive = value;

    }

    public boolean isAlive() {
        return ractive;
    }


}


