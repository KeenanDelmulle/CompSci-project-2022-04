/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

public class Alien extends Character {
    boolean moveRight, moveLeft, isVisible;

    public Alien(int x, int y, int s) {
        super(x, y, s);

        moveLeft = false;
        moveRight = false;
        isVisible = true;

        
    }

}
