/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

public class RunningGame {

    public RunningGame {


    }


    int x = 50;
        StdDraw.setXscale(0,100);
        StdDraw.setYscale(0,100);
        StdDraw.enableDoubleBuffering();

    Character

        while(true)

    {
        StdDraw.clear(); // clear screen
        //
        // draw enemy
        for (int y = 70; y < 100; y += 12) {
            for (int i = 8; i < 100; i += 12) {
                StdDraw.square(i, y, 4);
            }
        }

        StdDraw.circle(x, 7, 5); // draw shooter
        if (StdDraw.isKeyPressed(39) && x + 5 < 100) x += 1; // move to right
        if (StdDraw.isKeyPressed(37) && x - 5 > 0) x -= 1; //  move to left
        StdDraw.show();
        StdDraw.pause(15);
    }

}
}
        }
        }
