/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

public class Bullet {
    double rx, ry, rspeed;
    boolean ractive;

    public Bullet(double x, double y, double speed) {
        rx = x;
        ry = y;
        rspeed = speed;
        ractive = true;
    }

    public void resetBullet(double x, double y, double speed) {
        rspeed = speed;
        rx = x;
        ry = y;
        ractive = true;
    }

    public void destroy() {

        //clear bullet
        resetBullet(50 + 7, 7 + 7, 0);
    }

    public boolean Collision(Enemies[] villians) {
        int size = villians.length;
        boolean hit = false;
        for (int counter = 0; counter < size; counter++) {
            if (villians[counter].isAlive()) {

                double enx = villians[counter].getRx();
                double eny = villians[counter].getRy();


                if ((((rx + 2) == (enx - 4)) || ((rx - 2) == (enx + 4))) || ((ry + 2) == (eny
                        - 4))) {
                    villians[counter].changeState(false);


                    //destroy bullet


                    return true;
                }
            }


        }
        if (hit == false) {
            return false;
        }
        else {
            return true;
        }

    }
}

