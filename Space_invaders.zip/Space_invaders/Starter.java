/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import edu.princeton.cs.algs4.StdDraw;

import java.awt.Color;

//public static Character hero=new Character(50,7,0);


public class Starter {
    public static void DrawScreen(int rows) {
        StdDraw.setXscale(0, 100);
        StdDraw.setYscale(0, 100);
        StdDraw.filledRectangle(0, 0, 50, 50);
        StdDraw.enableDoubleBuffering();
   /*     for (int y = 1; y <= rows; y++) //drawing the characters
        {
            for (int x = 1; x <= 7; x++) {
                sprite[7 * (y - 1) + x].drawSprite(lives, speed, (x * 12 + 8), (rows * 12) + 70);

            }
        }
     */   //StdDraw.circle(50, 7, 5); // draw shooter
    }

    public static void titleScreen(Character h) {
        StdDraw.enableDoubleBuffering();

        StdDraw.setCanvasSize(1000, 3000);
        StdDraw.filledRectangle(0, 0, 500, 1500);
        StdDraw.setPenColor(Color.yellow);
        StdDraw.setXscale(-500, 500);
        StdDraw.setYscale(-1500, 1500);
        StdDraw.text(0, 300, "Space Invaders!", 0);
        StdDraw.text(0, 100, "Click 'space' to start the game", 0);
        StdDraw.text(0, 0, "Shoot", 0);
        StdDraw.text(0, -200, "Rotate: left (a), stop (s), right (d)", 0);
        StdDraw.text(0, -300, "Move: left (z), stop (x), right (c)", 0);
        StdDraw.text(0, -250, "Quit (q)", 0);
        StdDraw.setPenColor(Color.red);
        for (int i = 0; i < 100; i++) {
            double x = Math.random() * 1000;
            double y = Math.random() * 3000;
            StdDraw.point(x, y);

        }

        h.generatePlayer();


    }

    public static void main(String[] args) {

        Character hero = new Character(50, 7, 0);
        Bullet bullet = new Bullet(50 + 7, 7 + 7, 0);
        titleScreen(hero);

        boolean titlescreen = true;
        while (titlescreen) {


            if (StdDraw.isKeyPressed('q')) {
                // System.exit(0);
                titlescreen = false;

            }
            if (StdDraw.isKeyPressed(32)) //space bar
            {
                StdDraw.clear();
            }

        } //now we are off the title screen

        int points = 0;
        int level = 1;
        int enemynum = 0;
        int currentlevel = 1;
        int rows = level;
        if (rows > 4) rows = 4;
        DrawScreen(rows);
        int lives = 2;


        Enemies[] sprite = new Enemies[level
                * 4]; //(int num, int health, int speed, double x, double y)

        //Enemies(int num, int health, int speed, double x, double y)

        //double heroX = 50;

        while (currentlevel < 6 && lives != 0) {
            double enspeed = 0.5;
            double enx = 8;
            double eny = 96;


            // DEALING WITH INITIALISING THE ALIENS AT THE START OF EACH LEVEL!!!!
            for (int counter = 0; counter < level * 4; counter++) {
                if ((counter % 6) == 0) { //skip to next line
                    enx = 8;
                    eny = eny - 12;
                    sprite[counter] = new Enemies(lives, enspeed, enx, eny, true);
                }
                else {
                    enx = enx + 12;
                    sprite[counter] = new Enemies(lives, enspeed, enx, eny, true);
                }
                sprite[counter].generateAliens();
            }

            //run the game
            int hspeed = 1;
            // StdDraw.circle(x, 7, 5);//draw shooter
            if (StdDraw.isKeyPressed(39)) hero.movePlayerRight(hspeed); // move to right
            if (StdDraw.isKeyPressed(37)) hero.movePlayerLeft(hspeed); //  move to left

            if (hero.playerHit(sprite)) {
                lives--;   //if the player gets hit by a block (NEED TO ADD IF BLOCK IS BELOW A CERTAIN COORDINATE)
                //ALSO need to reset the level
            }
            if (bullet.Collision(sprite)) {  //if the bullet hits a villain
                bullet.destroy();
                points++;
            }


            // need to have a general collision case running

            // need to have a bullet shooting

            // need to clear the game once all enemies are dead

            //need to decrease lives if we are hit
            boolean levelComplete = true;
            for (int counter = 0; counter < sprite.length; counter++) {
                if (sprite[counter].isAlive() == true) {
                    levelComplete = false;
                }
            }
            if (levelComplete == false) {
                //reset board to next level
                level++;
                //Now we will re check everyting. THIS NEEDS TO GO LAST!!
            }

            StdDraw.show();
            StdDraw.pause(15);


        }


  /*

        }
*/

        //StdDraw.hasNextKeyTyped
      /*  while (true) {
            if (StdDraw.isKeyPressed('q')) {

                System.exit(0);

            }

        } */
    /*    if StdDraw.isKeyPressed(122)
        {
            //z
        }
        if StdDraw.isKeyPressed(97) //a
        {

        }
        if StdDraw.isKeyPressed(115)//s
        {

        }
        if StdDraw.isKeyPressed(100)//d
        {

        }
        if StdDraw.isKeyPressed(120)//x
        {

        }
        if StdDraw.isKeyPressed(99)//c
        {

        }
        if StdDraw.isKeyPressed(32) //space bar
        {

        }

*/
    }
}
