/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

import edu.princeton.cs.algs4.StdDraw;

public class Character {
    int rx, ry, rspeed;


    public Character(int x, int y, int speed) {
        rx = x;
        ry = y;
        rspeed = speed; //making our recieved values equal to the global variables.

    }

    public void generatePlayer() {
        StdDraw.circle(50, 7, 5);
    }

    public void movePlayerRight(int speed) {
        if (rx + 5 < 100) rx += speed;

        StdDraw.circle(rx, 7, 5);
    }

    public void movePlayerLeft(int speed) {
        if (rx - 5 > 0) rx -= speed;

        StdDraw.circle(rx, 7, 5);
    }

    public int getRx() {
        return rx;
    }

    public boolean playerHit(Enemies[] villians) {
        int size = villians.length;
        boolean hit = false;
        for (int counter = 0; counter < size; counter++) {
            if (villians[counter].isAlive()) {

                double enx = villians[counter].getRx();
                double eny = villians[counter].getRy();


                if ((((rx + 5) == (enx - 4)) || ((rx - 5) == (enx + 4))) || ((ry + 5) == (eny
                        - 4))) {
                    return true;
                }
            }

        }
        if (hit == false) {
            return false;
        }
        else {
            return true;
        }
   
    }
}

