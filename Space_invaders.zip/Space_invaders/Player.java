/* *****************************************************************************
 *  Name:              Ada Lovelace
 *  Coursera User ID:  123456
 *  Last modified:     October 16, 1842
 **************************************************************************** */

public class Player extends Character { // extends represents that Player is a child of character

    boolean moveRight, moveLeft;

    public Player(int x, int y, int s) {
        super(x, y,
              s);  //super sends the iunformation to the parent, which is Character in this case

        moveLeft = false;
        moveRight = false;
    }
}
